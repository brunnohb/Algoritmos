
/*18)	 Imprimir uma lista com as 10 primeiras letras do alfabeto:
	A
	B
	C
	D
	E
	F
	G
	H
	I
	J*/
package Exercicio_2;

public class Exercicio_2_18 {
	public static void main(String[] args) {

		char l1 = 'A';
		int n1 = 0;

		while (n1 <= 9) {
			System.out.println(l1);
			l1++;
			n1++;

		}

	}

}