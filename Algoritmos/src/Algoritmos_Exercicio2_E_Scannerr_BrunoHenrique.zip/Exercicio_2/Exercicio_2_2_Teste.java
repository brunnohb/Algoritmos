package Exercicio_2;

public class Exercicio_2_2_Teste {
	public static void main(String[] args) {

		int n1 = 0;

		while (n1 < 10)
			System.out.println("Resultado final: " + n1);
		n1++;
	}
}
