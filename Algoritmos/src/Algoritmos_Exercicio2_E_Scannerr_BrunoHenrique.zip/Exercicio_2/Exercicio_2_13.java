package Exercicio_2;

//13)	Imprima somente n�meros divis�veis por 5, de 1000 � 0;
public class Exercicio_2_13 {
	public static void main(String[] args) {

		int n1 = 1000;

		while (n1 >= 0) {
			System.out.println(n1);
			n1 = n1 - 5;
		}

	}
}
