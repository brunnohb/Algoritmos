package Exercicio_2;
//1)	Imprima no console uma lista de 0 a 10;
public class Exercicio_2_1 {
	public static void main(String[] args) {
		int n0 = 0;
		int n1 = 1;
		int n2 = 2;
		int n3 = 3;
		int n4 = 4;
		int n5 = 5;
		int n6 = 6;
		int n7 = 7;
		int n8 = 8;
		int n9 = 8;
		int n10 = 10;
			System.out.println(n0);
			System.out.println(n1);
			System.out.println(n2);
			System.out.println(n3);
			System.out.println(n4);
			System.out.println(n5);
			System.out.println(n6);
			System.out.println(n7);
			System.out.println(n8);
			System.out.println(n9);
			System.out.println(n10);
		
		
	}

}
