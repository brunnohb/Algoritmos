package Exercicio_2;

import javax.swing.JOptionPane;

/*21)	Desenhe a seguinte pir�mide de n�meros. O usu�rio determina a quantidade de linhas. 
Necessitar� de 2 for.
1
1 1  
1 1 1  
1 1 1 1
1 1 1 1 1
1 1 1 1 1 1  
*/

public class Exercicio_2_21 {
	public static void main(String[] args) {
		
		long n3 = 1;
		long n2 = 0;
		
		for(nn1 = 0; )
		
		
		}

	}
