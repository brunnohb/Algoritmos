package Exercicio_2;

//14)	Imprima somente n�meros que s�o m�ltiplos de 100, de -100 � 100;
public class Exercicio_2_14 {
	public static void main(String[] args) {

		int n1 = -100;

		while (n1 <= 100) {
			System.out.println(n1);

			n1 = n1 + 100;

		}

	}

}
